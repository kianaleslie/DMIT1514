﻿
using var game = new DMIT1514_Lab1.Game1();
game.Run();
