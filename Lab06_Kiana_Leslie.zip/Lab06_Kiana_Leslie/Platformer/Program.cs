﻿
using var game = new Platformer.Platformer();
game.Run();
